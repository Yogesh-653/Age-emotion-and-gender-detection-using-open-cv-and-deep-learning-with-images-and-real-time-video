from pathlib import Path
import cv2
import dlib
import sys
import numpy as np
from wide_resnet import WideResNet
from keras.utils import get_file
from keras.models import load_model
from tensorflow.keras.utils import img_to_array

classifier = load_model(r"D:\Yogesh_Emotion_Age_Gender_detection\Yogesh_Emotion_Age_Gender_detection\Main_File\model\emotion_little_vgg_2.h5")
pretrained_model = "https://github.com/yu4u/age-gender-estimation/releases/download/v0.5/weights.28-3.73.hdf5"
emotion_classes = {0: 'Angry', 1: 'Fear', 2: 'Happy', 3: 'Neutral', 4: 'Sad', 5: 'Surprise'}
modhash = 'fbe63257a054c1c5466cfd7bf14646d6'


def draw_label(image, point, label, font=cv2.FONT_HERSHEY_SIMPLEX,
               font_scale=0.8, thickness=1):
    size = cv2.getTextSize(label, font, font_scale, thickness)[0]
    x, y = point
    cv2.rectangle(image, (x, y - size[1]), (x + size[0], y), (255, 0, 0), cv2.FILLED)
    cv2.putText(image, label, (x, y), font, font_scale, (255, 255, 255), thickness, lineType=cv2.LINE_AA)

# Define model parameters
depth = 16
k = 8
weight_file = None
margin = 0.4
img_size = 64

# Get the weight file
if not weight_file:
    weight_file = get_file("weights.28-3.73.hdf5", pretrained_model, cache_subdir="pretrained_models",
                           file_hash=modhash, cache_dir=Path(sys.argv[0]).resolve().parent)

# Load model and weights
model = WideResNet(img_size, depth=depth, k=k)()
model.load_weights(weight_file)

detector = dlib.get_frontal_face_detector()

# Initialize Webcam
cap = cv2.VideoCapture(r"D:\Yogesh_Emotion_Age_Gender_detection\Yogesh_Emotion_Age_Gender_detection\Main_File\videos\Xinhua unveils world's first female AI news anchor.mp4")
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output_video.mp4', fourcc, 10.0, (int(cap.get(3)), int(cap.get(4))))

while True:
    ret, frame = cap.read()

    preprocessed_faces_emo = []

    input_img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img_h, img_w, _ = np.shape(input_img)
    detected = detector(frame, 1)
    faces = np.empty((len(detected), img_size, img_size, 3))

    preprocessed_faces_emo = []
    if len(detected) > 0:
        for i, d in enumerate(detected):
            x1, y1, x2, y2, w, h = d.left(), d.top(), d.right() + 1, d.bottom() + 1, d.width(), d.height()
            margin = 0.2
            xw1 = max(int(x1 - margin * w), 0)
            yw1 = max(int(y1 - margin * h), 0)
            xw2 = min(int(x2 + margin * w), img_w - 1)
            yw2 = min(int(y2 + margin * h), img_h - 1)

            cv2.rectangle(frame, (xw1, yw1), (xw2, yw2), (255, 0, 0), 2)

            faces[i, :, :, :] = cv2.resize(frame[yw1:yw2 + 1, xw1:xw2 + 1, :], (img_size, img_size))
            face = frame[yw1:yw2 + 1, xw1:xw2 + 1, :]

            # Predict emotion
            face_gray_emo = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
            face_gray_emo = cv2.resize(face_gray_emo, (48, 48), interpolation=cv2.INTER_AREA)
            face_gray_emo = face_gray_emo.astype("float") / 255.0
            face_gray_emo = img_to_array(face_gray_emo)
            face_gray_emo = np.expand_dims(face_gray_emo, axis=0)
            preprocessed_faces_emo.append(face_gray_emo)

        # Make predictions for Age and Gender
        results = model.predict(np.array(faces))
        predicted_genders = results[0]
        ages = np.arange(0, 101).reshape(101, 1)
        predicted_ages = results[1].dot(ages).flatten()

        # Make predictions for Emotion
        emo_labels = []
        for i, d in enumerate(detected):
            preds = classifier.predict(preprocessed_faces_emo[i])[0]
            emo_labels.append(emotion_classes[preds.argmax()])

        # Draw results
        for i, d in enumerate(detected):
            label_age = "Age: {}".format(int(predicted_ages[i]))
            label_gender = "Female" if predicted_genders[i][0] > 0.4 else "Male"
            label_emotion = emo_labels[i]

            # Adjusted positions for labels
            draw_label(frame, (xw1, yw1 - 10), label_age, font_scale=0.6)
            draw_label(frame, (xw1, yw1 + 20), label_gender, font_scale=0.6)
            draw_label(frame, (xw1, yw2 + 20), label_emotion, font_scale=0.6)

    out.write(frame)
    cv2.imshow("Emotion Detector", frame)
    if cv2.waitKey(1) == 13:  # 13 is the Enter Key
        break

cap.release()
out.release()
cv2.destroyAllWindows()
